package com.niit.rak;

public class NewPro1 {
	public static void main(String[]arg){
	int x=10;
	int y=20;
	if(x<y)
	{
		System.out.println("x is big");
	}
	else
	{
		System.out.println("y is big");
		
			}

	}
}

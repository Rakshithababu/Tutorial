package com.niit.rak.abc;

public class Employee {

}
